package com.reveth.spctils.features.dailyquest;

import com.reveth.spctils.config.SpctilsConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.List;

public class DailyQuestHud {

    public static void register() {
        HudRenderCallback.EVENT.register(DailyQuestHud::render);
    }

    private static void render(class_332 context, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842 || client.field_1724 == null) return;
        
        SpctilsConfig.ConfigData config = SpctilsConfig.get();
        if (!config.isHudEnabled) return;

        List<Quest> quests = DailyQuestState.getActiveQuests();
        class_327 textRenderer = client.field_1772;
        
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        String header = "Daily Quest [" + config.activeTracker.getDisplayName() + "]";
        int headerWidth = textRenderer.method_1727(header);

        SpctilsConfig.HudElementPosition pos = SpctilsConfig.getActiveLayoutProfile().positions.get("daily_quest");
        if (pos == null) pos = new SpctilsConfig.HudElementPosition(0.01, 0.01);
        
        int startX = (int) (screenWidth * pos.xPercent);
        int startY = (int) (screenHeight * pos.yPercent);

        if (quests.isEmpty()) {
            // Draw header and "Not Sync" state
            String notSyncText = "Not Sync";
            
            context.method_25303(textRenderer, header, startX, startY, 0xFF55FFFF); // Aqua color
            context.method_25303(textRenderer, notSyncText, startX, startY + 12, 0xFFFF5555); // Red color
            return;
        }

        // Calculate maximum width to align right
        int maxTextWidth = 0;
        for (Quest quest : quests) {
            String text = getQuestText(quest);
            int width = textRenderer.method_1727(text);
            if (width > maxTextWidth) {
                maxTextWidth = width;
            }
        }

        // Base coordinates (bottom right)
        // 16 pixels for icon + 4 pixels padding + text width
        int totalWidth = 16 + 4 + maxTextWidth;
        // Make sure total width covers the header if header is wider
        if (headerWidth > totalWidth) {
            totalWidth = headerWidth;
        }
        
        // Base coordinates removed, using startX and startY from Layout Profile
        context.method_25303(textRenderer, header, startX, startY, 0xFF55FFFF); // Aqua color

        int yOffset = 12; // below header
        for (Quest quest : quests) {
            int y = startY + yOffset;
            
            // Draw Icon
            if (quest.getIcon() != null && !quest.getIcon().method_7960()) {
                context.method_51427(quest.getIcon(), startX, y);
            }

            // Draw Text
            String text = getQuestText(quest);
            int color = quest.isCompleted() ? 0xFF55FF55 : 0xFFFFFFFF; // Green if done, else white
            context.method_25303(textRenderer, text, startX + 20, y + 4, color);

            yOffset += 20;
        }
    }

    private static String getQuestText(Quest quest) {
        return quest.getTargetName() + ": " + quest.getCurrentProgress() + "/" + quest.getMaxProgress();
    }
}
