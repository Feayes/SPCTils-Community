package com.reveth.spctils.features.dailyquest;

import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class Quest {
    private final String itemId;
    private final String targetName;
    private int currentProgress;
    private final int maxProgress;

    private transient class_1799 iconCache;

    public Quest(class_1799 icon, String targetName, int currentProgress, int maxProgress) {
        this.itemId = class_7923.field_41178.method_10221(icon.method_7909()).toString();
        this.iconCache = icon;
        this.targetName = targetName;
        this.currentProgress = currentProgress;
        this.maxProgress = maxProgress;
    }

    public class_1799 getIcon() {
        if (iconCache == null) {
            iconCache = class_7923.field_41178.method_63535(class_2960.method_60654(itemId)).method_7854();
        }
        return iconCache;
    }

    public String getTargetName() {
        return targetName;
    }

    public int getCurrentProgress() {
        return currentProgress;
    }

    public void incrementProgress() {
        if (this.currentProgress < this.maxProgress) {
            this.currentProgress++;
        }
    }

    public void resetProgress() {
        this.currentProgress = 0;
    }

    public int getMaxProgress() {
        return maxProgress;
    }

    public boolean isCompleted() {
        return currentProgress >= maxProgress;
    }
}
