package com.reveth.spctils.features.cooking;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

/**
 * Memetakan nama instruksi (dari lore buku) ke item Minecraft yang harus diklik,
 * lalu mencari slot yang berisi item tersebut di dalam ScreenHandler.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * MAPPING ITEM BERDASARKAN DATA AKTUAL GUI:
 *
 * Baris 1 (slot GUI atas, kiri → kanan):
 *   1. Tambah Rempah Rawa   → Items.BLAZE_POWDER    (blaze_powder)
 *   2. Besarkan Api Kuali   → Items.CAMPFIRE         (campfire)
 *   3. Aduk Rebusan         → Items.STICK            (stick)
 *   4. Cicipi Kuah Masakan  → Items.BOWL             (bowl)
 *   5. Tabur Garam Ajaib    → Items.GLOWSTONE_DUST  (glowstone_dust)
 *
 * Baris 2 (slot GUI bawah, kiri → kanan):
 *   6. Siram Kaldunya       → Items.WATER_BUCKET    (water_bucket)
 *   7. Tabur Gula Manis     → Items.SUGAR           (sugar)
 *   8. Kocok Adonan         → Items.WHEAT            (wheat)
 *   9. Tambah Arang Briket  → Items.CHARCOAL         (charcoal)
 *  10. Teteskan Madu Hutan  → Items.HONEY_BOTTLE    (honey_bottle)
 *
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class SlotMapper {

    /**
     * Map dari keyword instruksi (lowercase) ke Item yang harus diklik.
     *
     * Kita pakai partial match (instruksi.contains(key)), sehingga key boleh
     * berupa substring dari nama instruksi. Ini membuat matching lebih toleran
     * terhadap variasi spasi atau typo minor.
     *
     * LinkedHashMap menjaga urutan agar partial match diprioritaskan dari yang
     * paling spesifik ke paling umum.
     */
    private static final Map<String, class_1792> INSTRUKSI_MAP = new LinkedHashMap<>();

    static {
        // Baris 1
        INSTRUKSI_MAP.put("tambah rempah rawa",  class_1802.field_8183);  // 1: blaze_powder
        INSTRUKSI_MAP.put("besarkan api kuali",  class_1802.field_17346);       // 2: campfire
        INSTRUKSI_MAP.put("aduk rebusan",        class_1802.field_8600);          // 3: stick
        INSTRUKSI_MAP.put("cicipi kuah",         class_1802.field_8428);           // 4: bowl
        INSTRUKSI_MAP.put("tabur garam",         class_1802.field_8601); // 5: glowstone_dust

        // Baris 2
        INSTRUKSI_MAP.put("siram kaldunya",      class_1802.field_8705);   // 6: water_bucket
        INSTRUKSI_MAP.put("tabur gula manis",    class_1802.field_8479);          // 7: sugar
        INSTRUKSI_MAP.put("kocok adonan",        class_1802.field_8861);          // 8: wheat
        INSTRUKSI_MAP.put("tambah arang",        class_1802.field_8665);       // 9: charcoal
        INSTRUKSI_MAP.put("teteskan madu",       class_1802.field_20417);   // 10: honey_bottle
    }

    /**
     * Mencari nomor slot di dalam ScreenHandler yang berisi item
     * yang sesuai dengan instruksi aktif.
     *
     * @param handler    ScreenHandler GUI yang sedang terbuka
     * @param instruksi  Nama instruksi aktif (lowercase, sudah di-strip)
     * @return index slot (untuk dipakai di clickSlot()), atau -1 jika tidak ditemukan
     */
    public static int findSlotForInstruksi(class_1703 handler, String instruksi) {
        // Tentukan item target dari mapping
        class_1792 targetItem = resolveItem(instruksi);
        if (targetItem == null) return -1;

        // Telusuri semua slot di handler (termasuk inventory player)
        // Slot GUI biasanya ada di index awal sebelum inventory player
        for (int i = 0; i < handler.field_7761.size(); i++) {
            class_1735 slot = handler.field_7761.get(i);
            class_1799 stack = slot.method_7677();
            if (!stack.method_7960() && stack.method_7909() == targetItem) {
                return i; // kembalikan index slot pertama yang cocok
            }
        }

        return -1; // tidak ditemukan
    }

    /**
     * Mencocokkan teks instruksi ke Item menggunakan partial match.
     * Misalnya instruksi "tabur gula manis" akan cocok dengan key "tabur gula manis".
     *
     * @param instruksi teks instruksi aktif (lowercase)
     * @return Item yang harus diklik, atau null jika tidak ada yang cocok
     */
    public static class_1792 resolveItem(String instruksi) {
        if (instruksi == null || instruksi.isEmpty()) return null;

        for (Map.Entry<String, class_1792> entry : INSTRUKSI_MAP.entrySet()) {
            if (instruksi.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }
}
