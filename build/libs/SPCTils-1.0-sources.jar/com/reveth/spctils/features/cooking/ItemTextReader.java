package com.reveth.spctils.features.cooking;

import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9334;

/**
 * Membaca instruksi aktif dari item buku yang ada di dalam ScreenHandler.
 *
 * Format lore buku:
 *   Baris 0: "MANUAL INSTRUKSI KOKI"          ← header (diabaikan)
 *   Baris 1: ""                                 ← baris kosong (diabaikan)
 *   Baris 2: "Lakukan: <Nama Instruksi> (Klik 1x)"  ← INI yang kita baca
 *   Baris 3: "Progress Masakan: X/4 ..."
 */
public class ItemTextReader {

    /**
     * Menelusuri semua slot di ScreenHandler, mencari item buku,
     * lalu mengekstrak nama instruksi aktif dari lore-nya.
     *
     * @return nama instruksi (lowercase, sudah di-strip format code), atau null jika tidak ditemukan
     */
    public static String readActiveInstruksi(class_1703 handler) {
        for (class_1735 slot : handler.field_7761) {
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            // Cari item buku (book atau written_book)
            // Gunakan Items.WRITTEN_BOOK atau Items.WRITABLE_BOOK tergantung server
            net.minecraft.class_1792 item = stack.method_7909();
            if (item != net.minecraft.class_1802.field_8360
                    && item != net.minecraft.class_1802.field_8674
                    && item != net.minecraft.class_1802.field_8529) {
                continue;
            }

            // Coba baca dari LORE (DataComponentTypes.LORE)
            // Di 1.21+, lore disimpan sebagai ItemLore yang berisi List<Text>
            net.minecraft.class_9290 lore =
                    stack.method_58694(class_9334.field_49632);
            if (lore == null) continue;

            List<class_2561> loreLines = lore.comp_2400();
            if (loreLines == null || loreLines.isEmpty()) continue;

            for (class_2561 line : loreLines) {
                String raw = line.getString(); // ambil plain string (sudah tanpa §-code internal Text)
                // Strip format code Minecraft (§x) yang mungkin masih tersisa
                String stripped = stripFormatCodes(raw);

                // Cari baris yang dimulai dengan "Lakukan:"
                if (stripped.contains("Lakukan:")) {
                    // Format: "Lakukan: <Nama Instruksi> (Klik 1x)"
                    // Ambil teks di antara "Lakukan: " dan " (Klik"
                    int start = stripped.indexOf("Lakukan:") + "Lakukan:".length();
                    int end   = stripped.indexOf("(Klik");

                    if (start < 0 || end < 0 || end <= start) {
                        // Fallback: ambil semua setelah "Lakukan:"
                        return stripped.substring(start).trim().toLowerCase();
                    }

                    return stripped.substring(start, end).trim().toLowerCase();
                }
            }
        }
        return null; // tidak ada buku / instruksi tidak terbaca
    }

    /**
     * Menghapus karakter format Minecraft (§ diikuti satu karakter apapun)
     * dari sebuah string. Diperlukan karena server terkadang menyimpan
     * teks lore dengan embedded color/format code.
     */
    public static String stripFormatCodes(String text) {
        if (text == null) return "";
        // Regex: § diikuti karakter apapun (termasuk digit, huruf, dll)
        return text.replaceAll("§[0-9a-fk-or]", "");
    }
}
