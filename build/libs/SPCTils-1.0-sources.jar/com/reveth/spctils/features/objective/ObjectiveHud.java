package com.reveth.spctils.features.objective;

import com.reveth.spctils.config.SpctilsConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_345;
import net.minecraft.class_9779;

public class ObjectiveHud {

    public static void register() {
        HudRenderCallback.EVENT.register(ObjectiveHud::renderHud);
    }

    private static void renderHud(class_332 context, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1690.field_1842) return;
        
        if (!SpctilsConfig.get().showObjectiveHud) return;

        class_345 objectiveBar = null;
        java.util.Map<java.util.UUID, class_345> bossBars = ((com.reveth.spctils.mixin.BossBarHudAccessor) client.field_1705.method_1740()).getBossBars();
        for (class_345 bar : bossBars.values()) {
            // Strip § formatting codes before checking, since server may send colored text
            String plainName = bar.method_5414().getString().replaceAll("§.", "");
            if (plainName.contains("OBJEKTIF")) {
                objectiveBar = bar;
                break;
            }
        }

        if (objectiveBar != null) {
            class_327 textRenderer = client.field_1772;
            // Use the ordered Text (with colors) for display
            class_2561 text = objectiveBar.method_5414();
            
            SpctilsConfig.HudElementPosition pos = SpctilsConfig.getActiveLayoutProfile().positions.get("objective");
            if (pos == null) pos = new SpctilsConfig.HudElementPosition(0.01, 0.9);
            
            int x = (int) (client.method_22683().method_4486() * pos.xPercent);
            int y = (int) (client.method_22683().method_4502() * pos.yPercent);
            
            context.method_27535(textRenderer, text, x, y, 0xFFFFFFFF);
        }
    }
}
