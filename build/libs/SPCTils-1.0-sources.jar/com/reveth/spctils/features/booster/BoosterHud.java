package com.reveth.spctils.features.booster;

import com.reveth.spctils.config.SpctilsConfig;
import com.reveth.spctils.mixin.client.BossBarHudAccessor;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_345;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BoosterHud {

    public static void register() {
        HudRenderCallback.EVENT.register(BoosterHud::renderHud);
    }

    private static void renderHud(class_332 context, class_9779 tick) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1690.field_1842) return;
        
        SpctilsConfig.ConfigData config = SpctilsConfig.get();
        if (config.boosterDisplayMode != SpctilsConfig.BoosterDisplayMode.CUSTOM) {
            return;
        }

        Map<UUID, class_345> bossBars = ((BossBarHudAccessor) client.field_1705.method_1740()).getBossBars();
        List<class_345> boosters = new ArrayList<>();
        
        for (class_345 bar : bossBars.values()) {
            String name = bar.method_5414().getString();
            if (name.contains("[Weekend Booster]") || name.contains("[Weekday Booster]")) {
                boosters.add(bar);
            }
        }
        
        if (boosters.isEmpty()) return;

        class_327 tr = client.field_1772;
        int padding = 4;
        int lineHeight = 10;
        int boxHeight = 24; // Fits text nicely, like a potion effect box
        
        int screenW = context.method_51421();
        int screenH = context.method_51443();
        
        SpctilsConfig.HudElementPosition pos = SpctilsConfig.getActiveLayoutProfile().positions.get("booster");
        if (pos == null) pos = new SpctilsConfig.HudElementPosition(0.99, 0.95);
        
        int panelX = (int) (screenW * pos.xPercent);
        int curY = (int) (screenH * pos.yPercent);
        
        int maxBoxWidth = 0;
        List<String> displayStrings = new ArrayList<>();
        
        for (class_345 bar : boosters) {
            String fullName = bar.method_5414().getString().replaceAll("§.", "");
            String displayString = fullName;
            if (fullName.contains("] ")) {
                displayString = fullName.substring(fullName.indexOf("]") + 2).trim();
            }
            
            // Shorten text
            displayString = displayString.replace(" Booster Aktif!", "");
            displayString = displayString.replace("Regeneration", "Regen");
            displayString = displayString.replace(" / 6 Menit", "/6m");
            displayString = displayString.replace(" / 6 menit", "/6m");
            
            // Colors
            if (displayString.toLowerCase().contains("magic find")) {
                displayString = "§d" + displayString; // Pink/Magenta
            } else if (displayString.toLowerCase().contains("resin")) {
                displayString = "§b" + displayString.replace("(+", "§a(+").replace(" (-", "§c(-"); // Light Blue with Green numbers
            }
            
            displayStrings.add(displayString);
            
            int textW = tr.method_1727(displayString);
            int boxWidth = textW + padding * 4; // Extra padding for aesthetics
            if (boxWidth > maxBoxWidth) {
                maxBoxWidth = boxWidth;
            }
        }
        
        for (String displayString : displayStrings) {
            // Adjust X if aligned to the right
            int actualX = panelX;
            if (pos.xPercent > 0.5) {
                actualX -= maxBoxWidth;
            }
            
            // Background
            context.method_25294(actualX, curY, actualX + maxBoxWidth, curY + boxHeight, 0x90000000);
            
            // Border (Dark Gray)
            int borderColor = 0xFF555555;
            context.method_25294(actualX, curY, actualX + maxBoxWidth, curY + 1, borderColor); // Top
            context.method_25294(actualX, curY + boxHeight - 1, actualX + maxBoxWidth, curY + boxHeight, borderColor); // Bottom
            context.method_25294(actualX, curY, actualX + 1, curY + boxHeight, borderColor); // Left
            context.method_25294(actualX + maxBoxWidth - 1, curY, actualX + maxBoxWidth, curY + boxHeight, borderColor); // Right
            
            // Text
            int textW = tr.method_1727(displayString);
            int textX = actualX + (maxBoxWidth - textW) / 2; // Center text in the box
            int textY = curY + (boxHeight - 8) / 2;
            
            context.method_25303(tr, displayString, textX, textY, 0xFFFFFFFF);
            
            // Stack them vertically upwards if near the bottom, downwards if near the top
            if (pos.yPercent > 0.5) {
                curY -= (boxHeight + 2); // Move up for the next one
            } else {
                curY += (boxHeight + 2); // Move down for the next one
            }
        }
    }
}
