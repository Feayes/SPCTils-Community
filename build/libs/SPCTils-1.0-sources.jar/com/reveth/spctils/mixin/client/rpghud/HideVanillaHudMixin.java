package com.reveth.spctils.mixin.client.rpghud;

import com.reveth.spctils.config.SpctilsConfig;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class HideVanillaHudMixin {

    @Inject(method = "renderStatusBars", at = @At("HEAD"), cancellable = true)
    private void onRenderStatusBars(class_332 context, CallbackInfo ci) {
        if (SpctilsConfig.get().enableExperimentalRpgHud) {
            ci.cancel();
        }
    }
}
