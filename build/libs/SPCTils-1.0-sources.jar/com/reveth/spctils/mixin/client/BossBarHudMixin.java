package com.reveth.spctils.mixin.client;

import com.reveth.spctils.config.SpctilsConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import net.minecraft.class_337;
import net.minecraft.class_345;

@Mixin(class_337.class)
public class BossBarHudMixin {

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Ljava/util/Map;values()Ljava/util/Collection;"))
    private Collection<class_345> redirectBossBars(Map<UUID, class_345> map) {
        if (SpctilsConfig.get().boosterDisplayMode == SpctilsConfig.BoosterDisplayMode.ORIGINAL) {
            return map.values();
        }
        
        // Filter out boosters if mode is CUSTOM or HIDDEN
        return map.values().stream().filter(bar -> {
            String name = bar.method_5414().getString();
            return !name.contains("[Weekend Booster]") && !name.contains("[Weekday Booster]");
        }).collect(Collectors.toList());
    }
}
