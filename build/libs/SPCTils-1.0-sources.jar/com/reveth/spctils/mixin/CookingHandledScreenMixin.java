package com.reveth.spctils.mixin;

import com.reveth.spctils.features.cooking.CookingMod;
import com.reveth.spctils.features.cooking.CookingMod.FullAutoState;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import com.reveth.spctils.features.cooking.BotConfig;
import com.reveth.spctils.features.cooking.BotMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin ke HandledScreen (base class semua GUI container Minecraft).
 *
 * Tiga inject:
 *  1. init()          → deteksi GUI terbuka, update state machine Full-Auto
 *  2. removed()       → deteksi GUI tertutup, update state machine Full-Auto
 *  3. drawForeground()→ gambar highlight hijau pulsing pada slot target (Manual mode)
 */
@Mixin(class_465.class)
public class CookingHandledScreenMixin {

    private static final String KOKI_TITLE = "Instruksi Koki";

    /**
     * Shadow field HandledScreen.x / HandledScreen.y
     * (posisi top-left background GUI di layar, dipakai untuk koordinat highlight).
     */
    @Shadow protected int x;
    @Shadow protected int y;

    // ─── onInit ───────────────────────────────────────────────────────────────

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        @SuppressWarnings("unchecked")
        class_465<?> self = (class_465<?>) (Object) this;
        class_2561 title = self.method_25440();
        if (title == null) return;

        if (title.getString().contains(KOKI_TITLE)) {
            // ── Minigame "Instruksi Koki" terbuka ─────────────────────────────
            CookingMod.activeKokiScreen  = self;
            CookingMod.activeCookingMenu = null; // cooking menu pasti sudah tutup

            // Full-Auto: dari state apapun yang sedang menunggu → masuk minigame
            if (CookingMod.fullAutoState == FullAutoState.OPENING_MENU
                    || CookingMod.fullAutoState == FullAutoState.IN_COOKING_MENU
                    || CookingMod.fullAutoState == FullAutoState.WAITING_FOR_MINIGAME) {
                CookingMod.fullAutoState = FullAutoState.IN_MINIGAME;
            }

        } else {
            // ── GUI lain terbuka (cooking selection menu / chest biasa) ────────
            CookingMod.activeCookingMenu = self;

            // Full-Auto: cooking menu terbuka setelah right-click
            if (CookingMod.fullAutoState == FullAutoState.OPENING_MENU) {
                CookingMod.fullAutoState = FullAutoState.IN_COOKING_MENU;
            }
        }
    }

    // ─── onRemoved ────────────────────────────────────────────────────────────

    @Inject(method = "removed", at = @At("HEAD"))
    private void onRemoved(CallbackInfo ci) {
        @SuppressWarnings("unchecked")
        class_465<?> self = (class_465<?>) (Object) this;

        if (CookingMod.activeKokiScreen == self) {
            // Minigame tertutup
            CookingMod.activeKokiScreen = null;
            // Full-Auto: minigame selesai → kembali IDLE untuk loop ulang
            // (CookingMod.tickFullAuto() juga meng-handle ini via null check)
            if (CookingMod.fullAutoState == FullAutoState.IN_MINIGAME) {
                CookingMod.fullAutoState = FullAutoState.IDLE;
            }

        } else if (CookingMod.activeCookingMenu == self) {
            // Cooking menu tertutup
            CookingMod.activeCookingMenu = null;
            // Full-Auto: cooking menu tutup, kemungkinan minigame akan segera buka
            if (CookingMod.fullAutoState == FullAutoState.IN_COOKING_MENU) {
                CookingMod.fullAutoState = FullAutoState.WAITING_FOR_MINIGAME;
                // stateTimeout sudah berjalan dari saat masuk IN_COOKING_MENU
            }
        }
    }

    // ─── onDrawForeground (highlight slot — Manual mode) ──────────────────────

    /**
     * Inject di akhir drawForeground() untuk menggambar highlight slot target.
     *
     * WHY drawForeground (bukan render TAIL)?
     *   drawForeground() dipanggil DALAM konteks matrix yang sudah ditranslasi ke (x, y) GUI.
     *   Artinya slot.x dan slot.y langsung bisa dipakai sebagai koordinat fill — tidak perlu
     *   tambah offset this.x / this.y.
     *   Selain itu, drawForeground dipanggil SEBELUM tooltip, sehingga highlight
     *   tidak menutupi tooltip item.
     */
    @Inject(method = "drawForeground", at = @At("TAIL"))
    private void onDrawForeground(class_332 context, int mouseX, int mouseY, CallbackInfo ci) {
        // Hanya aktif di Manual mode
        if (!BotConfig.enabled || BotConfig.mode != BotMode.MANUAL) return;
        // Pastikan ini adalah layar minigame yang sedang kita track
        if (CookingMod.activeKokiScreen != (class_465<?>) (Object) this) return;
        if (CookingMod.highlightedSlotIndex < 0) return;

        class_1703 handler = ((class_465<?>) (Object) this).method_17577();
        if (CookingMod.highlightedSlotIndex >= handler.field_7761.size()) return;

        class_1735 slot = handler.field_7761.get(CookingMod.highlightedSlotIndex);

        // ── Solid highlight (tanpa efek kelip) ────────────────────────────────
        com.reveth.spctils.config.HighlightColor color =
                com.reveth.spctils.config.SpctilsConfig.get().cookingHighlightColor;

        // Overlay semi-transparan dengan warna pilihan
        context.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + 16, slot.field_7872 + 16, color.fillArgb());

        // Border putih solid di tepi slot (1px)
        int borderColor = 0xFFFFFFFF;
        int sx = slot.field_7873, sy = slot.field_7872;
        context.method_25294(sx,      sy,      sx + 16, sy + 1,  borderColor); // atas
        context.method_25294(sx,      sy + 15, sx + 16, sy + 16, borderColor); // bawah
        context.method_25294(sx,      sy,      sx + 1,  sy + 16, borderColor); // kiri
        context.method_25294(sx + 15, sy,      sx + 16, sy + 16, borderColor); // kanan
    }
}
