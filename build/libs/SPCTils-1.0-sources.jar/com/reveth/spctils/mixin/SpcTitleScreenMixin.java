package com.reveth.spctils.mixin;

import com.reveth.spctils.gui.SpcServersScreen;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public class SpcTitleScreenMixin extends class_437 {

    protected SpcTitleScreenMixin(class_2561 title) {
        super(title);
    }

    private class_4185 spcButton;
    private net.minecraft.class_344 spcIconWidget;
    private static final class_2960 SPC_ICON = class_2960.method_60655("spctils", "spc1");

    @Inject(method = "init", at = @At("TAIL"))
    private void addSpcButton(CallbackInfo ci) {
        int spcX = this.field_22789 / 2 + 104; // Default position just in case
        int spcY = this.field_22790 / 4 + 48 + 24 * 1;

        if (this.field_22787 != null && this.field_22787.method_1530()) {
            spcY += 24;
        }

        for (net.minecraft.class_364 element : this.method_25396()) {
            if (element instanceof class_4185 button) {
                if (button.method_25369().method_10851() instanceof net.minecraft.class_2588 textContent) {
                    if (textContent.method_11022().equals("menu.multiplayer")) {
                        spcY = button.method_46427();
                        break;
                    }
                }
            }
        }

        this.spcButton = class_4185.method_46430(
                class_2561.method_43473(),
                button -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new SpcServersScreen(this));
                    }
                }
        ).method_46434(spcX, spcY, 20, 20).method_46431();

        this.spcIconWidget = new net.minecraft.class_344(
                spcX + 2, spcY + 2, 16, 16,
                new net.minecraft.class_8666(SPC_ICON, SPC_ICON),
                button -> {},
                class_2561.method_43473()
        );

        this.method_37063(this.spcButton);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void renderSpcIcon(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.spcButton != null && this.spcButton.field_22764 && this.spcIconWidget != null) {
            this.spcIconWidget.method_46421(this.spcButton.method_46426() + 2);
            this.spcIconWidget.method_46419(this.spcButton.method_46427() + 2);
            this.spcIconWidget.method_25394(context, mouseX, mouseY, delta);
        }
    }
}
