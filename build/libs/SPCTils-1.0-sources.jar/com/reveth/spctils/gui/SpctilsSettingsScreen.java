package com.reveth.spctils.gui;

import com.reveth.spctils.config.QuestTrackerType;
import com.reveth.spctils.config.SpctilsConfig;
import com.reveth.spctils.features.cooking.BotConfig;
import com.reveth.spctils.features.cooking.BotMode;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SpctilsSettingsScreen extends class_437 {
    private final class_437 parent;
    private Tab currentTab = Tab.UTILITIES;

    private final int modalWidth = 260;
    private final int modalHeight = 210;

    public enum Tab { UTILITIES, COOKING, DEBUG, LAYOUT }

    public SpctilsSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("SPCTils Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        
        int modalX = (this.field_22789 - modalWidth) / 2;
        int modalY = (this.field_22790 - modalHeight) / 2;
        
        int tabBtnWidth = 80;
        int btnWidth = 160;
        int centerX = modalX + modalWidth / 2;
        int centerY = modalY + modalHeight / 2;

        SpctilsConfig.ConfigData config = SpctilsConfig.get();

        // Tabs
        class_4185 utilBtn = class_4185.method_46430(class_2561.method_43470("Utilities"), b -> { this.currentTab = Tab.UTILITIES; this.method_25426(); })
                .method_46434(modalX + 10, modalY + 30, tabBtnWidth, 20).method_46431();
        utilBtn.field_22763 = (this.currentTab != Tab.UTILITIES);
        this.method_37063(utilBtn);

        class_4185 cookBtn = class_4185.method_46430(class_2561.method_43470("Cooking"), b -> { this.currentTab = Tab.COOKING; this.method_25426(); })
                .method_46434(modalX + 10, modalY + 55, tabBtnWidth, 20).method_46431();
        cookBtn.field_22763 = (this.currentTab != Tab.COOKING);
        this.method_37063(cookBtn);

        class_4185 dbgBtn = class_4185.method_46430(class_2561.method_43470("Debug"), b -> { this.currentTab = Tab.DEBUG; this.method_25426(); })
                .method_46434(modalX + 10, modalY + 80, tabBtnWidth, 20).method_46431();
        dbgBtn.field_22763 = (this.currentTab != Tab.DEBUG);
        this.method_37063(dbgBtn);

        class_4185 layoutBtn = class_4185.method_46430(class_2561.method_43470("Layout"), b -> { this.currentTab = Tab.LAYOUT; this.method_25426(); })
                .method_46434(modalX + 10, modalY + 105, tabBtnWidth, 20).method_46431();
        layoutBtn.field_22763 = (this.currentTab != Tab.LAYOUT);
        this.method_37063(layoutBtn);

        // Content
        int contentX = modalX + 100;

        if (this.currentTab == Tab.UTILITIES) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Daily Quest HUD: " + (config.isHudEnabled ? "ON" : "OFF")),
                    button -> {
                        config.isHudEnabled = !config.isHudEnabled;
                        button.method_25355(class_2561.method_43470("Daily Quest HUD: " + (config.isHudEnabled ? "ON" : "OFF")));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 30, btnWidth - 10, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Tracker: " + config.activeTracker.getDisplayName()),
                    button -> {
                        QuestTrackerType[] values = QuestTrackerType.values();
                        int nextIndex = (config.activeTracker.ordinal() + 1) % values.length;
                        config.activeTracker = values[nextIndex];
                        button.method_25355(class_2561.method_43470("Tracker: " + config.activeTracker.getDisplayName()));
                        SpctilsConfig.save();
                        com.reveth.spctils.features.dailyquest.DailyQuestState.loadFromConfig(); // Reload instead of clear
                    })
                    .method_46434(contentX, modalY + 55, btnWidth - 10, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Objective HUD: " + (config.showObjectiveHud ? "ON" : "OFF")),
                    button -> {
                        config.showObjectiveHud = !config.showObjectiveHud;
                        button.method_25355(class_2561.method_43470("Objective HUD: " + (config.showObjectiveHud ? "ON" : "OFF")));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 80, btnWidth - 10, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Damage Counter: " + (config.showDamageCounter ? "ON" : "OFF")),
                    button -> {
                        config.showDamageCounter = !config.showDamageCounter;
                        button.method_25355(class_2561.method_43470("Damage Counter: " + (config.showDamageCounter ? "ON" : "OFF")));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 105, btnWidth - 10, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Booster UI: " + config.boosterDisplayMode.name()),
                    button -> {
                        SpctilsConfig.BoosterDisplayMode[] values = SpctilsConfig.BoosterDisplayMode.values();
                        int nextIndex = (config.boosterDisplayMode.ordinal() + 1) % values.length;
                        config.boosterDisplayMode = values[nextIndex];
                        button.method_25355(class_2561.method_43470("Booster UI: " + config.boosterDisplayMode.name()));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 130, btnWidth - 10, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Reset Quest Data"),
                    button -> {
                        com.reveth.spctils.features.dailyquest.DailyQuestState.clearQuests();
                        SpctilsConfig.save();
                        button.method_25355(class_2561.method_43470("Quests Reset!"));
                    })
                    .method_46434(contentX, modalY + 155, btnWidth - 10, 20)
                    .method_46431());
        } else if (this.currentTab == Tab.COOKING) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Bot Mode: " + BotConfig.mode.getDisplayName()),
                    button -> {
                        BotMode[] values = BotMode.values();
                        int nextIndex = (BotConfig.mode.ordinal() + 1) % values.length;
                        BotConfig.mode = values[nextIndex];
                        config.autoCookingMode = BotConfig.mode;
                        button.method_25355(class_2561.method_43470("Bot Mode: " + BotConfig.mode.getDisplayName()));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 30, btnWidth - 10, 20)
                    .method_46431());

            // Ticks adjuster with Arrows
            int tickCenterY = modalY + 55;
            
            // Decrease Button
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("<"),
                    button -> {
                        long handle = net.minecraft.class_310.method_1551().method_22683().method_4490();
                        int amount = (org.lwjgl.glfw.GLFW.glfwGetKey(handle, org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS || org.lwjgl.glfw.GLFW.glfwGetKey(handle, org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS) ? 10 : 1;
                        BotConfig.clickDelayTicks -= amount;
                        if (BotConfig.clickDelayTicks < 1) BotConfig.clickDelayTicks = 100;
                        config.autoCookingDelayTicks = BotConfig.clickDelayTicks;
                        SpctilsConfig.save();
                        this.method_25426(); // Refresh screen
                    })
                    .method_46434(contentX, tickCenterY, 20, 20)
                    .method_46431());

            // Increase Button
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(">"),
                    button -> {
                        long handle = net.minecraft.class_310.method_1551().method_22683().method_4490();
                        int amount = (org.lwjgl.glfw.GLFW.glfwGetKey(handle, org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS || org.lwjgl.glfw.GLFW.glfwGetKey(handle, org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS) ? 10 : 1;
                        BotConfig.clickDelayTicks += amount;
                        if (BotConfig.clickDelayTicks > 100) BotConfig.clickDelayTicks = 1;
                        config.autoCookingDelayTicks = BotConfig.clickDelayTicks;
                        SpctilsConfig.save();
                        this.method_25426(); // Refresh screen
                    })
                    .method_46434(contentX + btnWidth - 30, tickCenterY, 20, 20)
                    .method_46431());

            // Minigame Selector with Arrows
            int minigameCenterY = modalY + 80;
            
            // Decrease Button
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("<"),
                    button -> {
                        config.autoCookingMinigameSlot = (config.autoCookingMinigameSlot - 1 + 5) % 5;
                        SpctilsConfig.save();
                        this.method_25426(); // Refresh screen
                    })
                    .method_46434(contentX, minigameCenterY, 20, 20)
                    .method_46431());

            // Increase Button
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(">"),
                    button -> {
                        config.autoCookingMinigameSlot = (config.autoCookingMinigameSlot + 1) % 5;
                        SpctilsConfig.save();
                        this.method_25426(); // Refresh screen
                    })
                    .method_46434(contentX + btnWidth - 30, minigameCenterY, 20, 20)
                    .method_46431());

            // Highlight Color Selector
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Highlight: " + config.cookingHighlightColor.getDisplayName()),
                    button -> {
                        com.reveth.spctils.config.HighlightColor[] values = com.reveth.spctils.config.HighlightColor.values();
                        int nextIndex = (config.cookingHighlightColor.ordinal() + 1) % values.length;
                        config.cookingHighlightColor = values[nextIndex];
                        button.method_25355(class_2561.method_43470("Highlight: " + config.cookingHighlightColor.getDisplayName()));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 105, btnWidth - 10, 20)
                    .method_46431());
        } else if (this.currentTab == Tab.DEBUG) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Entity Debug: " + (config.debugEntityEnabled ? "\u00a7aON" : "\u00a7cOFF")),
                    button -> {
                        config.debugEntityEnabled = !config.debugEntityEnabled;
                        button.method_25355(class_2561.method_43470("Entity Debug: " + (config.debugEntityEnabled ? "\u00a7aON" : "\u00a7cOFF")));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 30, btnWidth - 10, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Player Debug: " + (config.debugPlayerEnabled ? "\u00a7aON" : "\u00a7cOFF")),
                    button -> {
                        config.debugPlayerEnabled = !config.debugPlayerEnabled;
                        button.method_25355(class_2561.method_43470("Player Debug: " + (config.debugPlayerEnabled ? "\u00a7aON" : "\u00a7cOFF")));
                        SpctilsConfig.save();
                    })
                    .method_46434(contentX, modalY + 55, btnWidth - 10, 20)
                    .method_46431());

            boolean rec = com.reveth.spctils.features.debug.PacketRecorder.isRecording();
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(rec ? "\u00a7cRecording... (click to stop)" : "Record Packets (60s)"),
                    button -> {
                        if (com.reveth.spctils.features.debug.PacketRecorder.isRecording()) {
                            com.reveth.spctils.features.debug.PacketRecorder.stopAndSave();
                            button.method_25355(class_2561.method_43470("Record Packets (60s)"));
                        } else {
                            com.reveth.spctils.features.debug.PacketRecorder.start();
                            button.method_25355(class_2561.method_43470("\u00a7cRecording... (click to stop)"));
                        }
                    })
                    .method_46434(contentX, modalY + 80, btnWidth - 10, 20)
                    .method_46431());
        } else if (this.currentTab == Tab.LAYOUT) {
            // Profile selector
            int profileCenterY = modalY + 30;
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("<"),
                    button -> {
                        config.activeLayoutProfileIndex = (config.activeLayoutProfileIndex - 1 + 3) % 3;
                        SpctilsConfig.save();
                        this.method_25426(); // Refresh screen
                    })
                    .method_46434(contentX, profileCenterY, 20, 20)
                    .method_46431());

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Profile " + (config.activeLayoutProfileIndex + 1)),
                    button -> {})
                    .method_46434(contentX + 20, profileCenterY, btnWidth - 50, 20)
                    .method_46431()).field_22763 = false; // Just for display

            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(">"),
                    button -> {
                        config.activeLayoutProfileIndex = (config.activeLayoutProfileIndex + 1) % 3;
                        SpctilsConfig.save();
                        this.method_25426(); // Refresh screen
                    })
                    .method_46434(contentX + btnWidth - 30, profileCenterY, 20, 20)
                    .method_46431());
                    
            // Edit Profile Button
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Edit Profile"),
                    button -> {
                        this.field_22787.method_1507(new SpctilsLayoutEditScreen(this));
                    })
                    .method_46434(contentX, modalY + 55, btnWidth - 10, 20)
                    .method_46431());
        }

        // Done Button
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Done"),
                button -> this.field_22787.method_1507(this.parent))
                .method_46434(centerX - 40, modalY + modalHeight - 30, 80, 20)
                .method_46431());
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25420(context, mouseX, mouseY, delta);
        
        int modalX = (this.field_22789 - modalWidth) / 2;
        int modalY = (this.field_22790 - modalHeight) / 2;
        
        // Compact modal background (Minecraft tooltip style)
        context.method_25296(modalX, modalY, modalX + modalWidth, modalY + modalHeight, 0xF0101010, 0xF0101010);
        
        // Border using fill (top, bottom, left, right)
        context.method_25294(modalX - 1, modalY - 1, modalX + modalWidth + 1, modalY, 0xFF555555); // Top
        context.method_25294(modalX - 1, modalY + modalHeight, modalX + modalWidth + 1, modalY + modalHeight + 1, 0xFF555555); // Bottom
        context.method_25294(modalX - 1, modalY, modalX, modalY + modalHeight, 0xFF555555); // Left
        context.method_25294(modalX + modalWidth, modalY, modalX + modalWidth + 1, modalY + modalHeight, 0xFF555555); // Right
        
        // Vertical separator for tabs
        context.method_25294(modalX + 95, modalY + 25, modalX + 96, modalY + modalHeight - 35, 0xFF555555);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        
        int modalX = (this.field_22789 - modalWidth) / 2;
        int modalY = (this.field_22790 - modalHeight) / 2;
        
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, modalY + 10, 0xFFFFFF);
        
        if (this.currentTab == Tab.COOKING) {
            int contentX = modalX + 100;
            int tickCenterY = modalY + 55;
            int minigameCenterY = modalY + 80;
            int btnWidth = 160;
            context.method_27534(this.field_22793, class_2561.method_43470("Delay: " + BotConfig.clickDelayTicks + " ticks"), contentX + (btnWidth - 10) / 2, tickCenterY + 6, 0xFFFFFFFF);
            context.method_27534(this.field_22793, class_2561.method_43470(getMinigameName(SpctilsConfig.get().autoCookingMinigameSlot)), contentX + (btnWidth - 10) / 2, minigameCenterY + 6, 0xFFFFFFFF);
        }
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(this.parent);
    }

    private String getMinigameName(int slot) {
        switch(slot) {
            case 0: return "Bread";
            case 1: return "Herbal Broth";
            case 2: return "Hunter's Roast";
            case 3: return "Nectar Stew";
            case 4: return "Cathy Steak";
            default: return "Slot " + (slot + 1);
        }
    }
}
