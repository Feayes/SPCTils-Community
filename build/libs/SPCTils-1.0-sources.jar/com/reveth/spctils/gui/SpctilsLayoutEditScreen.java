package com.reveth.spctils.gui;

import com.reveth.spctils.config.SpctilsConfig;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.HashMap;

public class SpctilsLayoutEditScreen extends class_437 {
    private final class_437 parent;
    private SpctilsConfig.LayoutProfile profile;
    private String draggingElement = null;
    
    // For hitboxes
    private final Map<String, Rect> bounds = new HashMap<>();

    public SpctilsLayoutEditScreen(class_437 parent) {
        super(class_2561.method_43470("Edit Layout"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        this.profile = SpctilsConfig.getActiveLayoutProfile();

        // Save Button
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Save"),
                button -> {
                    SpctilsConfig.save();
                    this.field_22787.method_1507(this.parent);
                })
                .method_46434(this.field_22789 / 2 - 40, this.field_22790 / 2 - 10, 80, 20)
                .method_46431());
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Semi-transparent background
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0xC0101010, 0xC0101010);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        bounds.clear();
        
        // Draw instructions
        context.method_25300(this.field_22793, "Drag to move HUD elements", this.field_22789 / 2, this.field_22790 / 2 - 25, 0xFFFF55);

        int screenW = this.field_22789;
        int screenH = this.field_22790;

        // Render dummy Daily Quest
        SpctilsConfig.HudElementPosition questPos = profile.positions.computeIfAbsent("daily_quest", k -> new SpctilsConfig.HudElementPosition(0.01, 0.01));
        int questX = (int) (screenW * questPos.xPercent);
        int questY = (int) (screenH * questPos.yPercent);
        int questW = 120;
        int questH = 40;
        context.method_25294(questX, questY, questX + questW, questY + questH, 0x800000AA);
        context.method_25303(this.field_22793, "Daily Quest HUD", questX + 4, questY + 4, 0xFFFFFFFF);
        bounds.put("daily_quest", new Rect(questX, questY, questW, questH));

        // Render dummy Objective
        SpctilsConfig.HudElementPosition objPos = profile.positions.computeIfAbsent("objective", k -> new SpctilsConfig.HudElementPosition(0.01, 0.9));
        int objX = (int) (screenW * objPos.xPercent);
        int objY = (int) (screenH * objPos.yPercent);
        int objW = 100;
        int objH = 20;
        context.method_25294(objX, objY, objX + objW, objY + objH, 0x8000AA00);
        context.method_25303(this.field_22793, "Objective HUD", objX + 4, objY + 4, 0xFFFFFFFF);
        bounds.put("objective", new Rect(objX, objY, objW, objH));

        // Render dummy Damage Counter
        SpctilsConfig.HudElementPosition dmgPos = profile.positions.computeIfAbsent("damage", k -> new SpctilsConfig.HudElementPosition(0.55, 0.55));
        int dmgX = (int) (screenW * dmgPos.xPercent);
        int dmgY = (int) (screenH * dmgPos.yPercent);
        int dmgW = 100;
        int dmgH = 40;
        context.method_25294(dmgX, dmgY, dmgX + dmgW, dmgY + dmgH, 0x80AA0000);
        context.method_25303(this.field_22793, "Damage HUD", dmgX + 4, dmgY + 4, 0xFFFFFFFF);
        bounds.put("damage", new Rect(dmgX, dmgY, dmgW, dmgH));

        // Render dummy Player Debug
        SpctilsConfig.HudElementPosition pdPos = profile.positions.computeIfAbsent("player_debug", k -> new SpctilsConfig.HudElementPosition(0.8, 0.2));
        int pdX = (int) (screenW * pdPos.xPercent);
        int pdY = (int) (screenH * pdPos.yPercent);
        int pdW = 100;
        int pdH = 100;
        context.method_25294(pdX, pdY, pdX + pdW, pdY + pdH, 0x80AAAA00);
        context.method_25303(this.field_22793, "Player Debug", pdX + 4, pdY + 4, 0xFFFFFFFF);
        bounds.put("player_debug", new Rect(pdX, pdY, pdW, pdH));

        // Render dummy Booster HUD
        SpctilsConfig.HudElementPosition bstPos = profile.positions.computeIfAbsent("booster", k -> new SpctilsConfig.HudElementPosition(0.99, 0.95));
        int bstW = 150;
        int bstH = 24;
        int bstX = (int) (screenW * bstPos.xPercent);
        int bstY = (int) (screenH * bstPos.yPercent);
        if (bstPos.xPercent > 0.5) bstX -= bstW;
        context.method_25294(bstX, bstY, bstX + bstW, bstY + bstH, 0x805500AA);
        context.method_25303(this.field_22793, "Booster HUD", bstX + 4, bstY + 8, 0xFFFFFFFF);
        bounds.put("booster", new Rect(bstX, bstY, bstW, bstH));
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 click, boolean bl) {
        if (click.method_74245() == 0) { // Left click
            for (Map.Entry<String, Rect> entry : bounds.entrySet()) {
                if (entry.getValue().contains((int) click.comp_4798(), (int) click.comp_4799())) {
                    draggingElement = entry.getKey();
                    return true; // Consume event
                }
            }
        }
        return super.method_25402(click, bl);
    }

    @Override
    public boolean method_25403(net.minecraft.class_11909 click, double deltaX, double deltaY) {
        if (draggingElement != null && click.method_74245() == 0) {
            SpctilsConfig.HudElementPosition pos = profile.positions.get(draggingElement);
            if (pos != null) {
                Rect r = bounds.get(draggingElement);
                if (r != null) {
                    double newXPercent = pos.xPercent + (deltaX / (double) this.field_22789);
                    double newYPercent = pos.yPercent + (deltaY / (double) this.field_22790);
                    
                    // Clamp
                    pos.xPercent = Math.max(0.0, Math.min(1.0, newXPercent));
                    pos.yPercent = Math.max(0.0, Math.min(1.0, newYPercent));
                }
            }
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(net.minecraft.class_11909 click) {
        if (click.method_74245() == 0) {
            draggingElement = null;
        }
        return super.method_25406(click);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static class Rect {
        int x, y, w, h;
        Rect(int x, int y, int w, int h) {
            this.x = x; this.y = y; this.w = w; this.h = h;
        }
        boolean contains(int mx, int my) {
            return mx >= x && mx <= x + w && my >= y && my <= y + h;
        }
    }
}
