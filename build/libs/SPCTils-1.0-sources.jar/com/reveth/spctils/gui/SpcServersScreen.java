package com.reveth.spctils.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class SpcServersScreen extends class_437 {
    private final class_437 parent;

    public SpcServersScreen(class_437 parent) {
        super(class_2561.method_43470("SPC Servers"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 4 + 48;

        // Button 1: play.spcid.net
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("IP 1 : play.spcid.net (play)"),
                button -> connect("play.spcid.net", "SPC Play"))
                .method_46434(centerX - 100, centerY, 200, 20)
                .method_46431());

        // Button 2: mc.spcid.net
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("IP 2 : mc.spcid.net (mc)"),
                button -> connect("mc.spcid.net", "SPC Survival"))
                .method_46434(centerX - 100, centerY + 24, 200, 20)
                .method_46431());

        // Button 3: indie.spcid.net
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("IP 3 : indie.spcid.net (indie)"),
                button -> connect("indie.spcid.net", "SPC Indie"))
                .method_46434(centerX - 100, centerY + 48, 200, 20)
                .method_46431());

        // Back Button
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Back"),
                button -> this.field_22787.method_1507(this.parent))
                .method_46434(centerX - 100, centerY + 96, 200, 20)
                .method_46431());
    }

    private void connect(String ip, String name) {
        class_642 info = new class_642(name, ip, class_642.class_8678.field_45611);
        class_412.method_36877(this.parent, this.field_22787, class_639.method_2950(ip), info, false, null);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
    }
}
