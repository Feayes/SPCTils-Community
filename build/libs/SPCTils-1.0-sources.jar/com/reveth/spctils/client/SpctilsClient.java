package com.reveth.spctils.client;

import com.reveth.spctils.Spctils;
import com.reveth.spctils.config.SpctilsConfig;
import com.reveth.spctils.gui.SpctilsSettingsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class SpctilsClient implements ClientModInitializer {
    private static class_304 settingsKeyBinding;
    private static class_304 toggleCookingKeyBinding;

    @Override
    public void onInitializeClient() {
        Spctils.LOGGER.info("[SPCTils] Client initialized.");

        // Load config
        SpctilsConfig.load();

        // Register keybinding
        settingsKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.spctils.settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_EQUAL, // Default to '='
                class_304.class_11900.method_74698(net.minecraft.class_2960.method_60655("spctils", "utilities"))
        ));

        toggleCookingKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.spctils.cooking.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_MINUS,
                class_304.class_11900.method_74698(net.minecraft.class_2960.method_60655("spctils", "cooking"))
        ));

        com.reveth.spctils.features.objective.ObjectiveHud.register();
        com.reveth.spctils.features.damage.DamageTrackerHud.register();
        com.reveth.spctils.features.booster.BoosterHud.register();
        com.reveth.spctils.features.rpghud.CustomRpgHudRenderer.register();

        // Listen for key press
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKeyBinding.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new SpctilsSettingsScreen(null));
                }
            }
            while (toggleCookingKeyBinding.method_1436()) {
                com.reveth.spctils.features.cooking.BotConfig.enabled = !com.reveth.spctils.features.cooking.BotConfig.enabled;
                if (client.field_1724 != null) {
                    if (com.reveth.spctils.features.cooking.BotConfig.enabled) {
                        client.field_1724.method_7353(class_2561.method_43470("§e[AutoKoki] §aBot diaktifkan §7(" + com.reveth.spctils.features.cooking.BotConfig.mode.getDisplayName() + ")"), true);
                    } else {
                        client.field_1724.method_7353(class_2561.method_43470("§e[AutoKoki] §cBot dimatikan"), true);
                    }
                }
            }
        });

        // ── Register features ────────────────────────────────────────────────
        com.reveth.spctils.features.dailyquest.DailyQuestManager.register();
        com.reveth.spctils.features.dailyquest.DailyQuestHud.register();
        new com.reveth.spctils.features.cooking.CookingMod().register();
        new com.reveth.spctils.features.debug.PlayerDebugHud().register();
        // ────────────────────────────────────────────────────────────────────
    }
}
