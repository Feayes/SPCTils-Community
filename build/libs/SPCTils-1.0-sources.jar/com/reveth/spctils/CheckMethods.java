package com.reveth.spctils;
import java.lang.reflect.Method;
import net.minecraft.class_329;
public class CheckMethods {
    public static void main(String[] args) {
        for (Method m : class_329.class.getDeclaredMethods()) {
            if (m.getName().toLowerCase().contains("render")) {
                System.out.println(m.getName() + " " + java.util.Arrays.toString(m.getParameterTypes()));
            }
        }
    }
}
